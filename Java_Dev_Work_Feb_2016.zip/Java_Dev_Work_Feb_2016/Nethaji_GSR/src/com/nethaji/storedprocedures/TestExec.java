package com.nethaji.storedprocedures;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
public class TestExec {
	
	
	
	
	
	
	
	public static boolean restoreDatabase() throws FileNotFoundException, IOException, InterruptedException
	{
		String mySqlPath = "";
		String path = "";
	    List<String> args = new ArrayList<>();
	    mySqlPath = "C:\\oraclexe\\app\\oracle\\product\\10.2.0\\server\\BIN\\oracle.exe";

	    args.add(mySqlPath);

	    // Comands
	    args.add("-u");
	    args.add("SYSTEM");
	    args.add("--password=gsr@123");
	    args.add("testingimport");

	    System.out.println("Args: "+args.toString());

	    try{
	    	
	        ProcessBuilder pb = new ProcessBuilder(args);
	        pb.redirectError();
	        Process p = pb.start();

	        path = "E:/Testingimport/Test.sql";
	        InputStream fileInputStream = new FileInputStream(new File(path));
	        byte[] b = new byte[4096];

	        while(fileInputStream.read(b) != -1) {
	            p.getOutputStream().write(b);
	        }

	        p.getOutputStream().close(); // don't forget to close!
	        InputStream is = p.getInputStream();

	        int in = -1;
	        while((in = is.read()) != -1)
	        {
	            System.out.print(""+(char) in);
	        }

	        int proccessCompleted = p.waitFor();

	        if(proccessCompleted == 0)
	        {
	            System.out.println("Dump done!");
	            return true;
	        }
	        else
	        {
	            System.out.println("Error doing dump!");
	            return false;
	        }
	    }
	    catch(IOException | InterruptedException ex)
	    {
	        System.out.println("Exception exportDB -> " + ex.getMessage() + "|" + ex.getLocalizedMessage());
	    }
	    return false;
	}
	
	
	
	
	public static void importDump() throws IOException, InterruptedException
	{
		Process p = null;
		Runtime r = Runtime.getRuntime();
		String setPathtoBIN = "cd C:\\oraclexe\\app\\oracle\\product\\10.2.0\\server\\BIN";
		String cmdDump = "impdp SYSTEM/gsr@123";
		String javaPath = "set path=C:\\Program Files\\Java\\jdk1.8.0_74\\bin";
		String enVariable = "set ORACLE_HOME=C:\\oraclexe\\app\\oracle\\product\\10.2.0\\server";
		String openFile = "@E:\\Testingimport\\import.sql";
		 p = r.exec("cmd /c "+openFile);
		if(p.waitFor()==0)
		{
		 System.out.println("Command Executed Successfully");
		 p = r.exec("cmd /c "+setPathtoBIN);
		 if(p.waitFor()==0)
			{
			 System.out.println("Path Set is Done");
			 p = r.exec("cmd /c impdp");
			 if(p.waitFor()==0)
				{
				 System.out.println("Dump Commond Called");
				 BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
		         String line = null;
		         while ((line = in.readLine()) != null) {
		             System.out.println(line);
		         }
				}
			 
			}
		 
		 
		}
		
		String javac = "javac";
		 Process p2 = Runtime.getRuntime().exec("cmd /c "+javac);
		 BufferedReader in = new BufferedReader(new InputStreamReader(p2.getInputStream()));
         String line = null;
         while ((line = in.readLine()) != null) {
             System.out.println(line);
         }
	}
	
	
	
    public static void main(String[] args) throws FileNotFoundException, IOException, InterruptedException {
    	
    
    	importDump();
    	
    	
    	
    	
       /* try {
        	String cmd = "C:\\oraclexe\\app\\oracle\\product\\10.2.0\\server\\BIN\\oracle.exe";
            Process p = Runtime.getRuntime().exec(" cmd javac");
            BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = null;
            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }*/
    }
}