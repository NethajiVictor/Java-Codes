package com.nethaji.storedprocedures;

import org.omg.SendingContext.RunTime;

public class ImportDB {

	public static void main(String[] args) {

		
		System.out.println(RunTime.class.getTypeParameters());

	}

}
