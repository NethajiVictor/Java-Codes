package com.nethaji.storedprocedures;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class StoredProcedures1 {
	
	public static void executeStoredprocNoParams(Connection con) {
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("{call GETCUSTNAME}");
            while (rs.next()) {
            System.out.println(rs.getString("Name"));
            }
            rs.close();
            stmt.close();
            }
        catch (Exception e) {
            e.printStackTrace();
            }
}

	public static void main(String[] args) throws ClassNotFoundException {
		
		Connection con = JDBCConnection.getConnection();
		executeStoredprocNoParams(con);
		

	}

}
