package com.nethaji.storedprocedures;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class OpenFileFromComputer {
	
	
	public static void openFile(String path) throws IOException, InterruptedException 
	{
		Process p = null;
		Runtime r = Runtime.getRuntime();
		p = r.exec("cmd /c "+path);
		if(p.waitFor()!=0)
		{
			 System.err.println("Can't Open : "+path);
			BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
	         String line = null;
	         while ((line = in.readLine()) != null) {
	             System.out.println(line);
	            
	         }
		}


		
	}

	public static void main(String[] args) throws IOException, InterruptedException {
			openFile("@C:\\Program Files (x86)\\Adobe\\Reader 11.0\\Reader\\AcroRd32.exe");

	}

}
