package com.nethaji.demos;

public class StringReverseWholeWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
