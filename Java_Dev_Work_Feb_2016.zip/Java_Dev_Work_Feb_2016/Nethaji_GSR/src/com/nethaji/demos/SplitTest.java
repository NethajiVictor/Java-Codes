package com.nethaji.demos;

import java.util.UUID;

public class SplitTest{
   public static void main(String args[]){

	  System.out.println();
   }
}