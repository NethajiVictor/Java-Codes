package com.nethaji.demos;

public class FactorialRecursionSimple {
	static int fact = 1;

	public static void findFact(int num) {
		if (num > 0) {
			fact = fact * num;
			findFact(num - 1);
		}

	}

	public static void main(String[] args) {
		findFact(6);
		System.out.println("Factorial : " + fact);

	}

}
