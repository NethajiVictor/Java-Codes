package com.nethaji.demos;

public class PictureFromVideo {

	public static void main(String[] args) {
		
		

	}

}
