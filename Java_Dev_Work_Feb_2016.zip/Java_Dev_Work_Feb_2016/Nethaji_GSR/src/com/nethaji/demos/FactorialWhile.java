package com.nethaji.demos;

public class FactorialWhile {

	public static void factorial(int num) {
		int fact = 1;
		while (num > 0) {
			fact = fact * num;
			num--;
		}
		System.out.println("Factorial : " + fact);
	}

	public static void main(String[] args) {
		factorial(5);

	}

}
