package com.nethaji.demos;

public class WordCount {
	
	public static void countTheWords(String s)
	{
		String[] str = s.split(" ");
		int length = str.length;
		System.out.println("Count of the words : "+length);
		
		for(int i=0;i<str.length;i++)
		{
			System.out.println(str[i]);
		}

		for(int i=str.length-1;i>=0;i--)
		{
			System.out.println(str[i]);
		}
	}

	public static void main(String[] args) {

		countTheWords("Nethaji Manikandan Victor Netha N sdijs i");

	}

}
