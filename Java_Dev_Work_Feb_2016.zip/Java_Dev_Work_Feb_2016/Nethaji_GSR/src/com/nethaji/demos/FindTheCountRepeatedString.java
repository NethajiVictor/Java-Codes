package com.nethaji.demos;

import java.util.HashMap;
import java.util.Map;

public class FindTheCountRepeatedString {

	public static void main(String[] args) {
		findStringRepeatedByMap("Nethaji Nethaji Ajith Nethaji");
	}

	public static void findStringRepeatedByMap(String str) {
		String temp = "";
		Character ch1, ch2;
		Map<String, Integer> strMap = new HashMap<String, Integer>();
		int length = str.length();
		for (int i = 0; i < length; i++) {
			ch1 = str.charAt(i);
			if (ch1 == 'a' || ch1 == 'A') {
				if (i + 1 < length) {
					ch2 = str.charAt(i + 1);
					if (ch2 == 'j' || ch2 == 'J') {
						temp = ch1.toString() + ch2.toString();
						temp = temp.toLowerCase();
						if (strMap.containsKey(temp)) {
							strMap.put(temp, strMap.get(temp) + 1);
						} else {
							strMap.put(temp, 1);
						}

					}
				}
			}
		}
		String key = "arj";
		Integer result = strMap.get(key);
		if(result==null)
		{
			System.err.println("Please provide valid key.!");
		} else
		{
		System.out.println("Count of the String '" + key + "' : " +result );
		}

	}

}
