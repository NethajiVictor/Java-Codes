package com.nethaji.demos;

public class SentenceReverse {
	
	// Hello How Are You - olleH woH erA uoY
	
	
	public static void reverseSentence(String sentence)
	{
		System.out.println("Original Sentence : "+sentence);
		sentence = sentence + " ";
		int length = sentence.length();
		String output ="";
		Character ch,ch2;
		for(int i=0;i<length;i++)
		{
			ch = sentence.charAt(i);
			if(ch==' ')
			{
				for(int j=i-1;j>=0;j--)
				{
					ch2 = sentence.charAt(j);
					if(ch2==' ')
					{
						break;
					}
					output = output + ch2.toString();
				}
				output = output + ch.toString();
			}
			
		}
		
		System.out.println("Reverse Sentence : "+output);
		
	}
	

	
	
	public static void reverseSentence2(String sentence)
	{
		System.out.println("Original : "+sentence);
		int len = sentence.length();
		for(int i=len-1;i>=0;i--)
		{
			sentence = sentence + sentence.charAt(i);
		}
		sentence = sentence.substring(len);
		String[] arr = sentence.split(" ");
		for(int i=arr.length-1;i>=0;i--)
		{
			sentence = sentence + arr[i] + " ";
			
		}
		sentence = sentence.substring(len);
		
		System.out.println("Reversed : "+sentence);
		

	}
	

	public static void main(String[] args) {

		reverseSentence2("Hello How Are You");
		

	}

}
