package com.nethaji.demos;

public class WriteImage 
{	
    public static void main( String[] args )
    {
    	
    }
}