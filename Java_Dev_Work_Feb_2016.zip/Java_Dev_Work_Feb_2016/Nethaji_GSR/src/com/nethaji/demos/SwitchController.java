package com.nethaji.demos;

public class SwitchController {


	static
	{
		System.out.println("Hi How are you");
	}
	
	
	
	
	public static void main(String args[])
	{
		
	}
	
	

}
