package com.nethaji.demos;

import java.util.ArrayList;
import java.util.List;

public class CombineArrayList {

	public static void main(String[] args) {

		int arr1[] = { 1, 2, 3, 4, 5 };
		int arr2[] = { 6, 7, 8, 9, 1, 2, 3, 4, 5 };
		int len1 = arr1.length;
		int len2 = arr2.length;
		List<Integer> numList = new ArrayList<Integer>();
		for (int i = 0; (i < len1) | (i < len2); i++) {
			if (i < len1) {
				numList.add(arr1[i]);
			}
			if (i < len2) {
				numList.add(arr2[i]);
			}

		}

		for (Integer in : numList) {
			System.out.print(in + " ");
		}

	}

}
