package com.nethaji.demos;

import javax.crypto.Cipher;
 import javax.crypto.BadPaddingException;
 import javax.crypto.IllegalBlockSizeException;
 import javax.crypto.KeyGenerator;
 import java.security.Key;
 import java.security.InvalidKeyException;
 
 public class EncryptionAndDecryption {
 
      private static String algorithm = "DESede";
      private static Key key = null;
      private static Cipher cipher = null;
      private static String  key1 = "1234";
 
      private static void setUp() throws Exception {
          key = KeyGenerator.getInstance(algorithm).generateKey();
          /*key = 
          System.out.println("Key is : "+key1);*/
          
          cipher = Cipher.getInstance(algorithm);
      }
 
      public static void main(String[] args) 
         throws Exception {
          setUp();
          if (args.length !=1) {
              System.out.println(
                "USAGE: java LocalEncrypter " +
                                       "[String]");
              System.exit(1);
          }
          byte[] encryptionBytes = null;
          String input = args[0];
          System.out.println("Entered: " + input);
          encryptionBytes = encrypt(input);
          System.out.println("Encrypted : "+encryptionBytes.toString());
          System.out.println(
            "Recovered: " + decrypt(encryptionBytes));
      }
 
      private static byte[] encrypt(String input)
          throws InvalidKeyException, 
                 BadPaddingException,
                 IllegalBlockSizeException {
          cipher.init(Cipher.ENCRYPT_MODE, key);
          System.out.println("Cipher.ENCRYPT_MODE : "+Cipher.ENCRYPT_MODE);
          System.out.println("Cipher.DECRYPT_MODE : "+Cipher.DECRYPT_MODE);
        
          byte[] inputBytes = input.getBytes();
          return cipher.doFinal(inputBytes);
      }
 
      private static String decrypt(byte[] encryptionBytes)
          throws InvalidKeyException, 
                 BadPaddingException,
                 IllegalBlockSizeException {
          cipher.init(Cipher.DECRYPT_MODE, key);
          byte[] recoveredBytes = 
            cipher.doFinal(encryptionBytes);
          String recovered = 
            new String(recoveredBytes);
          return recovered;
        }
 }