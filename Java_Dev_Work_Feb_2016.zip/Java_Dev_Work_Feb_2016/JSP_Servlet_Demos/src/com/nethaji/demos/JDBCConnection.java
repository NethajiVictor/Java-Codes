package com.nethaji.demos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;

public class JDBCConnection {
	
	
	public static Connection getConnection() throws ClassNotFoundException
	{
		Connection connection = null;
		
		String driver = "oracle.jdbc.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		
		
	    try {
	    	Class.forName(driver);
			connection = DriverManager.getConnection(url, "SYSTEM", "gsr@123");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return connection;
	}
	
	
	public static void main(String args[]) throws ClassNotFoundException, SQLException
	{
		PreparedStatement ps= null;
		Connection con = null;
	
		try {
			con = JDBCConnection.getConnection();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		String sql = "INSERT INTO EMP(ID,NAME,ADDRESS,EMAIL,PASSWORD)VALUES(?,?,?,?,?)";
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, new Date().getSeconds());
			ps.setString(2, "Name");
			ps.setString(3, "CHENNAI");
			ps.setString(4, "Email");
			ps.setString(5, "Pass");
			
			int res = ps.executeUpdate();
			System.out.println(res);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			
			try {
				ps.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
