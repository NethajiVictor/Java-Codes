package com.nethaji.demos;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/LoginPage")
public class LoginPage extends HttpServlet {
	private static String  errorMessage = "";
	private static final long serialVersionUID = 1L;



	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String userName = request.getParameter("uname");
		String password = request.getParameter("pass");
		String redirect = "main.jsp";
		String fail = "login.jsp";
		if(userName.equalsIgnoreCase(""))
		{
			errorMessage = "Username should not be empty.";
			request.setAttribute("errorMessage", errorMessage);
			request.getRequestDispatcher(fail).forward(request, response);
			
		} 
		if(password.equalsIgnoreCase(""))
		{
			errorMessage = "Password should not be empty.";
			request.setAttribute("errorMessage", errorMessage);
			request.getRequestDispatcher(fail).forward(request, response);
		} 
		if(!userName.equalsIgnoreCase("Nethaji") && !password.equalsIgnoreCase("12345"))
		{
			errorMessage = "Wrong Username / Password.";
			request.setAttribute("errorMessage", errorMessage);
			request.getRequestDispatcher(fail).forward(request, response);
		} 
		if(userName.equalsIgnoreCase("Nethaji") && password.equalsIgnoreCase("12345"))
		{
			 response.sendRedirect(redirect);
		}
		
		
	}


}
