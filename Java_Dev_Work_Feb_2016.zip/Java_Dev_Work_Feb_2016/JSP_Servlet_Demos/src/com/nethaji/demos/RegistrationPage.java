package com.nethaji.demos;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/RegistrationPage")
public class RegistrationPage extends HttpServlet {
	private static String message = "";
	private static final long serialVersionUID = 1L;
	private PreparedStatement ps = null;
	private Connection con = null;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection connection = null;
		int contact = 0;
		try
		{
			contact = Integer.parseInt(request.getParameter("contact"));
		} catch(Exception e)
		{
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		String redirect = "register.jsp";
		GSRObjects obj = new GSRObjects();
		obj.setName(request.getParameter("name"));
		obj.setEmail(request.getParameter("email"));
		obj.setUserName(request.getParameter("uname"));
		obj.setPassword(request.getParameter("confirmPass"));
		obj.setGender(request.getParameter("gender"));
		obj.setContact(contact);
		
			try {
				connection = JDBCConnection.getConnection();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		
		String sql = "INSERT INTO GSR_USER(NAME,EMAIL,USERNAME,PASSWORD,GENDER,CONTACT) VALUES (?,?,?,?,?,?)";
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, obj.getName());
			ps.setString(2, obj.getEmail());
			ps.setString(3, obj.getUserName());
			ps.setString(4, obj.getPassword());
			ps.setString(5, obj.getGender());
			ps.setInt(6, obj.getContact());
			ps.executeUpdate();
			message = "Successfully Registered.!";
			request.setAttribute("message", message);
			request.getRequestDispatcher(redirect).forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			
			try {
				ps.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		
		
		
		
		

	}

}
