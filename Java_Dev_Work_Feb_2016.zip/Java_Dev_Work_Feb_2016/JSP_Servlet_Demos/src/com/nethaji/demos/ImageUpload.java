package com.nethaji.demos;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/ImageUpload")
public class ImageUpload extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String errorMessage="",successMessage="";
	private static PreparedStatement ps = null;
	private static Connection connection = null;
	private static final String TABLE = "IMAGE_REFERENCE";

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String uniqueID = null;
		String fileName = null;
		String name = request.getParameter("fileName");
		String uploadedBy = request.getParameter("uploadBy");
		String uploadPage = "imageupload.jsp";
		String savePath = "D:/Images/";
		
		if(uploadedBy.equals("")||uploadedBy==null)
		{
			errorMessage = "Name should not be empty.";
    		request.setAttribute("errorMessage", errorMessage);
    		request.getRequestDispatcher(uploadPage).forward(request, response);
			
		}
		BufferedImage image = null;
        try {
          
            File file = new File(name);
            image = ImageIO.read(file);
            uniqueID = ""+UUID.randomUUID();
            fileName = uniqueID+".jpg";
            String filePath = savePath+fileName;
            boolean isDone = ImageIO.write(image, "jpg",new File(savePath+fileName));
            if(isDone)
            {
            	boolean isUploaded = makeEntryInDatabase(uniqueID, fileName, filePath, uploadedBy);
            	if(isUploaded)
            	{
            	
            		successMessage = "Image Successfully Uploaded.";
            		request.setAttribute("successMessage", successMessage);
            		request.getRequestDispatcher(uploadPage).forward(request, response);
            	}
            	else
                {
                	errorMessage = "Error .";
        			request.setAttribute("errorMessage", errorMessage);
        			request.getRequestDispatcher(uploadPage).forward(request, response);
                }
            } 
            else
            {
            	errorMessage = "Error Occured.";
    			request.setAttribute("errorMessage", errorMessage);
    			request.getRequestDispatcher(uploadPage).forward(request, response);
            }
            
            
        } catch (IOException e) {
			request.setAttribute("errorMessage", e.getMessage());
			request.getRequestDispatcher(uploadPage).forward(request, response);
        }
        
		
	}
	

	public static java.sql.Timestamp utilDatetoSqlTimeStamp(java.util.Date utilDate) {
		if (utilDate != null) {
			java.sql.Timestamp sqlDate1 = new java.sql.Timestamp(utilDate
					.getTime());
			return sqlDate1;
		} else {
			return null;
		}
	}
	
	
	public static boolean makeEntryInDatabase(String id,String fileName,String filePath,String uploadedBy)
	{
		boolean isUpdated = false;
		int result = 0;
		
		try {
			connection = JDBCConnection.getConnection();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	
	String sql = "INSERT INTO "+TABLE+"(ID,IMAGE_NAME,FILE_PATH,UPLOADED_DATE,UPLOADED_BY) VALUES (?,?,?,?,?)";
	try {
		ps = connection.prepareStatement(sql);
		ps.setString(1, id);
		ps.setString(2, fileName);
		ps.setString(3, filePath);
		ps.setTimestamp(4, utilDatetoSqlTimeStamp(new Date()));
		ps.setString(5, uploadedBy);
		result = ps.executeUpdate();
		if(result!=0 && result>0)
		{
			isUpdated = true;
		} 

	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally {
		
		try {
			ps.close();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		
		
		
		
		
		return isUpdated;
	}

}
