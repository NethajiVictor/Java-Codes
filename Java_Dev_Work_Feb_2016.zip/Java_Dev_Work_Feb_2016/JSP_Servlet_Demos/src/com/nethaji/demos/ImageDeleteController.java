package com.nethaji.demos;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ImageDeleteController")
public class ImageDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String errorMessage = "", successMessage = "";
	private static String id="",fileName="",uploadedDate="",uploadedBy="";

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String name = request.getParameter("name");
		if(name==null || name.equals(""))
		{
			errorMessage = "Name should not be empty.";
    		request.setAttribute("errorMessage", errorMessage);
    		request.getRequestDispatcher("imageview.jsp").forward(request, response);
    		
		}
		List<ImageData> dataList = getData(name);
		if(dataList!=null&&dataList.size()!=0)
		{

        		request.setAttribute("list",dataList);
        		request.getRequestDispatcher("imageview.jsp").forward(request, response);
			
		} else
		{
			errorMessage = "No data found.";
    		request.setAttribute("errorMessage", errorMessage);
    		request.getRequestDispatcher("imageview.jsp").forward(request, response);
		}
		
	}
	
	public static List<ImageData> getData(String name)
	{
		 Connection connection = null;

		try {
			connection = JDBCConnection.getConnection();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		List<ImageData> reultList = new ArrayList<ImageData>();
		
		try 
		{
			String sql = "SELECT * FROM IMAGE_REFERENCE WHERE UPLOADED_BY = ?";
			PreparedStatement ps = null;
			ps = connection.prepareStatement(sql);
			ps.setString(1, name);
			ResultSet rs = ps.executeQuery();
			if(rs!=null)
			{
				while(rs.next())
				{
					ImageData data = new ImageData();
					data.setId(rs.getString("ID"));
					data.setFileName(rs.getString("IMAGE_NAME"));
					data.setFilePath(rs.getString("FILE_PATH"));
					data.setUploadedDate(rs.getString("UPLOADED_DATE"));
					data.setUploadedBy(rs.getString("UPLOADED_BY"));
					data.setCheck(false);
					reultList.add(data);
					
				}
				
			}
			ps.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				connection.commit();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return reultList;

	}
	

}
